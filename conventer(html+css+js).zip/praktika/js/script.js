window.onload = function () {
    $.getJSON("https://www.cbr-xml-daily.ru/daily_json.js", function(data) {
        let s1 = data.Valute.USD.Value; // Доллар
        let s2 = data.Valute.EUR.Value;
        let s3 = data.Valute.CNY.Value; // Евро
        let c = {'USD':s1, 'EUR':s2, 'RUB':'1', 'CNY':s3}; // курс валют (можно добавить еще)
        document.getElementById('dollar').innerText = s1.toFixed(2);
        document.getElementById('euro').innerText = s2.toFixed(2);
        document.getElementById('cny').innerText = s3.toFixed(2);
        // Получаем элементы формы ввода и вывода
        let inputVal = document.getElementById('input_sum'); 
        let outputVal = document.getElementById('output_sum'); 
        let currency1 = document.getElementById('cur1'); 
        let currency2 = document.getElementById('cur2');  
        let result = document.getElementsByClassName('convert_result')[0]; // результат выводится в блок с классом convert_result
        
        function convert() {
            let z = 0;
            if(currency1.value === currency2.value){
                result.innerText = inputVal.value; // Выводим введенное значение
            } else {
                if(currency1.value != 'RUB'){
                    z = inputVal.value * c[currency1.value]; // Переводим в рубли
                    outputVal.value = Math.ceil((z / c[currency2.value]) * 100) / 100; // Делим на курс и округляем до сотых
                } else {
                    outputVal.value = Math.ceil((inputVal.value / c[currency2.value]) * 100) / 100; // Переводим, но не в рубли
                }
            }
        }
        
        // Навешиваем обработчики событий на элементы формы ввода
        inputVal.oninput = convert;
        currency1.onchange = convert;
        currency2.onchange = convert;
    });
}
