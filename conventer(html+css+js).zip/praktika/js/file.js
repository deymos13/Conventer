document.addEventListener('DOMContentLoaded', function() {
    document.addEventListener('click', function(event) {
        if (event.target.closest('.konvert_form_img')) {
            var div1 = document.querySelector('.cbrf_value1');
            var div2 = document.querySelector('.cbrf_value2');
            var button = document.querySelector('.konvert_form_img');

            // Сохраняем ссылки на элементы формы
            var input1 = div1.querySelector('input');
            var select1 = div1.querySelector('select');
            
            var input2 = div2.querySelector('input');
            var select2 = div2.querySelector('select');
            
            // Меняем местами значения input
            var tempValue = input1.value;
            input1.value = input2.value;
            input2.value = tempValue;
            
            // Меняем местами выбранные опции select
            var tempIndex = select1.selectedIndex;
            select1.selectedIndex = select2.selectedIndex;
            select2.selectedIndex = tempIndex;
            
            // Меняем местами элементы в DOM, вставляя кнопку между ними
            div1.parentNode.insertBefore(button, div1);
            div1.parentNode.insertBefore(div2, button);
        }
    });
});
